module invisible/relay

go 1.21

require (
	github.com/gorilla/websocket v1.5.1
	go.etcd.io/bbolt v1.3.9
)
